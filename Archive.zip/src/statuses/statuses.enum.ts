export enum StatusEnum {
  'active' = 1,
  'inactive' = 2,
}

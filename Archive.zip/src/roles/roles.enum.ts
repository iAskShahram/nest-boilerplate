export enum RoleEnum {
  'admin' = 1,
  'user' = 2,
}

export type OrNeverType<T> = T | never;

export type MaybeType<T> = T | undefined;
